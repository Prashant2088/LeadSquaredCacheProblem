﻿// <copyright file="Base64Extensions.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>


using System.Text;

namespace AuthenticationCacheCore.Extensions
{
    /// <summary>
    /// Extension methods to convert string from and to base64 string.
    /// </summary>
    public static class Base64Extensions
    {
        /// <summary>
        /// Decodes the bas64 encoded string and returns the actual value.
        /// </summary>
        /// <param name="base64EncodedData">Base64 encoded string value.</param>
        /// <returns>Decoded string value.</returns>
        public static string Base64Decode(this string base64EncodedData)
        {
            if (string.IsNullOrEmpty(base64EncodedData) && string.IsNullOrWhiteSpace(base64EncodedData))
            {
                throw new ArgumentNullException(nameof(base64EncodedData), "Value cannot be null or empty.");
            }

            var base64EncodedBytes = Convert.FromBase64String(base64EncodedData);
            return Encoding.UTF8.GetString(base64EncodedBytes);
        }

        /// <summary>
        /// Encodes string value to base64 encoded string value.
        /// </summary>
        /// <param name="plainText">String value.</param>
        /// <returns>Base64 encoded string value.</returns>
        public static string Base64Encode(this string plainText)
        {
            if (string.IsNullOrEmpty(plainText) && string.IsNullOrWhiteSpace(plainText))
            {
                return plainText;
            }

            var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            return Convert.ToBase64String(plainTextBytes);
        }
    }
}