﻿// <copyright file="CacheExtensions.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>


using AuthenticationCacheCore.Caching;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;

namespace AuthenticationCacheCore.Extensions
{
    /// <summary>
    /// Extension Methods In Memory and Distributed Cache Entry Options
    /// </summary>
    public static class CacheExtensions
    {
        /// <summary>
        /// Gets connection string from <paramref name="cacheSettings"/>.
        /// </summary>
        /// <param name="cacheSettings">The <see cref="CacheSettings"/>.</param>
        /// <returns>The connection string.</returns>
        public static string GetConnectionString(this CacheSettings cacheSettings)
        {
            if (cacheSettings is null)
            {
                throw new ArgumentNullException(nameof(cacheSettings));
            }

            var redisCacheOptions = cacheSettings.RedisCacheOptions;
            var redisConfiguration = redisCacheOptions!.Configuration;
            var redisConfigurationOptions = redisCacheOptions!.ConfigurationOptions;

            return $"{redisConfiguration},ssl={redisConfigurationOptions.Ssl},user={redisConfigurationOptions.User}," +
                $"password={redisConfigurationOptions.Password},allowAdmin={redisConfigurationOptions.AllowAdmin}";
        }

        /// <summary>
        /// Gets <see cref="DistributedCacheEntryOptions"/> from <see cref="CacheEntryOptions"/>.
        /// </summary>
        /// <param name="options"><see cref="CacheEntryOptions">The cache entry options</see>.</param>
        /// <returns><see cref="DistributedCacheEntryOptions"/>.</returns>
        public static DistributedCacheEntryOptions DistributedCacheEntryOptions(this CacheEntryOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            return new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(options.AbsoluteExpirationRelativeToNowInSeconds),
                SlidingExpiration = TimeSpan.FromSeconds(options.SlidingExpirationInSeconds)
            };
        }

        /// <summary>
        /// Gets <see cref="MemoryCacheEntryOptions"/> from <see cref="CacheEntryOptions"/>.
        /// </summary>
        /// <param name="options"><see cref="CacheEntryOptions">The cache entry options</see>.</param>
        /// <returns><see cref="MemoryCacheEntryOptions"/>.</returns>
        public static MemoryCacheEntryOptions MemoryCacheEntryOptions(this CacheEntryOptions options)
        {
            if (options is null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            return new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(options.AbsoluteExpirationRelativeToNowInSeconds),
                SlidingExpiration = TimeSpan.FromSeconds(options.SlidingExpirationInSeconds),
                Size = options.Size
            };
        }
    }
}