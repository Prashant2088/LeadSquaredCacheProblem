﻿// <copyright file="JsonExtensions.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using System.Text.Json;
using System.Text.Json.Serialization;

#nullable disable

namespace System
{
    /// <summary>
    /// Extension methods to convert objects from and to Json.
    /// </summary>
    public static class JsonExtensions
    {
        private static readonly JsonSerializerOptions DefaultJsonSerializerOptions = new()
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
            // MaxDepth = 6
        };

        /// <summary>
        /// Deserializes a json string to an object using <see cref="JsonSerializer"/>.
        /// </summary>
        /// <typeparam name="T">Object Type.</typeparam>
        /// <param name="value">Json value.</param>
        /// <returns>object representation of Json string passed.</returns>
        public static T JsonDeSerialize<T>(this string value)
        {
            if (typeof(T) == typeof(string))
            {
                return (T)(object)value;
            }

            return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(value);
        }

        /// <summary>
        /// Serializes an object into Json string based on the serializer options <see cref="JsonSerializerOptions"/> using <see cref="JsonSerializer"/>.
        /// </summary>
        /// <typeparam name="T">Object Type.</typeparam>
        /// <param name="request">Object Instance.</param>
        /// <param name="serializerOptions">Serialization options <see cref="JsonSerializerOptions"/>.</param>
        /// <returns>Json string representation of the object.</returns>
        public static string JsonSerialize<T>(this T request, JsonSerializerOptions serializerOptions)
        {
            return JsonSerializer.Serialize(request, serializerOptions ?? DefaultJsonSerializerOptions);
        }

    }
}