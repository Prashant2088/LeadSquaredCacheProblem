﻿// <copyright file="ApiDocumentationExtensions.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Configuration;

using NSwag;
using OperationSecurityScopeProcessor = NSwag.Generation.Processors.Security.OperationSecurityScopeProcessor;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// Extension methods to configure API Documentation.
    /// </summary>
    public static class ApiDocumentationExtensions
    {
        /// <summary>
        /// Adds API versioning.
        /// </summary>
        /// <param name="services">The <see cref="IServiceCollection">service collection</see>.</param>
        /// <param name="configuration">The <see cref="IConfiguration">application configuration</see>.</param>
        /// <param name="serviceProvider">The <see cref="IServiceProvider">service provider</see>.</param>
        /// <param name="serviceName">The service name.</param>
        /// <returns><see cref="IServiceCollection"/>.</returns>
        public static IServiceCollection AddApiDocumentation(
            this IServiceCollection services,
            IConfiguration configuration,
            IServiceProvider serviceProvider,
            string serviceName)
        {
            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (configuration is null)
            {
                throw new ArgumentNullException(nameof(configuration));
            }

            if (serviceProvider is null)
            {
                throw new ArgumentNullException(nameof(serviceProvider));
            }

            if (string.IsNullOrEmpty(serviceName))
            {
                throw new ArgumentException($"'{nameof(serviceName)}' cannot be null or empty.", nameof(serviceName));
            }


            var apiVersionDescriptionProvider = serviceProvider.GetRequiredService<IApiVersionDescriptionProvider>();
            if (configuration["ApiDocumentSettings:Enabled"].Equals("True", StringComparison.OrdinalIgnoreCase))
            {
                foreach (ApiVersionDescription apiVersionDescription in apiVersionDescriptionProvider.ApiVersionDescriptions)
                {
                    AddApiDocumentForVersion(services, serviceName, apiVersionDescription);
                }
            }

            return services;
        }

        private static void AddApiDocumentForVersion(
            IServiceCollection services,
            string serviceName,
            ApiVersionDescription apiVersionDescription)
        {
            var version = $"v{apiVersionDescription.ApiVersion}";
            services.AddOpenApiDocument((Action<NSwag.Generation.AspNetCore.AspNetCoreOpenApiDocumentGeneratorSettings>)(config =>
            {
                config.DocumentName = version;
                config.ApiGroupNames = new[] { apiVersionDescription.ApiVersion.ToString() };
                config.PostProcess = (document) =>
                {
                    document.Info.Version = version;
                    document.Info.Title = serviceName;
                };

                if (apiVersionDescription.IsDeprecated)
                {
                    config.Description += " This API version has been deprecated. Please use one of the new APIs available from the explorer.";
                }

                config.OperationProcessors.Add(new OperationSecurityScopeProcessor("bearer"));
                config.AddSecurity("bearer", new OpenApiSecurityScheme
                {
                    Type = OpenApiSecuritySchemeType.ApiKey,
                    Name = "Authorization",
                    Description = "Copy 'Bearer ' + valid JWT token into field",
                    In = OpenApiSecurityApiKeyLocation.Header
                });
            }));
        }
    }
}