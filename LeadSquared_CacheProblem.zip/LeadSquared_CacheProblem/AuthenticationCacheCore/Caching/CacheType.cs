﻿// <copyright file="CacheType.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

namespace AuthenticationCacheCore.Caching
{
    /// <summary>
    /// Represnts cache type enumeration.
    /// </summary>
    public enum CacheType
    {
        /// <summary>
        /// Indicates the cache will stored in memory.
        /// </summary>
        Memory,

        /// <summary>
        /// Indicates the cache will be using distributed cache like redis.
        /// </summary>
        Distributed
    }
}