﻿// <copyright file="CacheEntryOptions.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

namespace AuthenticationCacheCore.Caching
{
    /// <summary>
    /// Represents cache entry options.
    /// </summary>
    public class CacheEntryOptions
    {
        /// <summary>
        /// Gets or sets absolure expiration time relative to now in seconds. Default value is 60.
        /// </summary>
        public int AbsoluteExpirationRelativeToNowInSeconds { get; set; } = 60;

        /// <summary>
        /// Gets or sets cache entry size. Default value is 1.
        /// </summary>
        public int Size { get; set; } = 1;

        /// <summary>
        /// Gets or sets sliding expiration time in seconds. Default value is 10.
        /// </summary>
        public int SlidingExpirationInSeconds { get; set; } = 10;
    }
}