﻿// <copyright file="CacheSettings.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using AuthenticationCacheCore.Extensions;
using Microsoft.Extensions.Caching.StackExchangeRedis;

namespace AuthenticationCacheCore.Caching
{
    /// <summary>
    /// Represents cache settings.
    /// </summary>
    public class CacheSettings
    {
        /// <summary>
        /// Gets or sets <see cref="CacheEntryOptions"/>.
        /// </summary>
        public CacheEntryOptions? CacheEntryOptions { get; set; }

        /// <summary>
        /// Gets or sets <see cref="CacheType"/>.
        /// </summary>
        public CacheType CacheType { get; set; }

        /// <summary>
        /// Gets or sets cche key prefix.
        /// </summary>
        public string? KeyPrefix { get; set; }

        /// <summary>
        /// Gets or sets <see cref="RedisCacheOptions"/>.
        /// </summary>
        public RedisCacheOptions? RedisCacheOptions { get; set; }

        /// <summary>
        /// Gets cache key prefixed by <see cref="CacheSettings.KeyPrefix"/>. Cache Key is base64 encoded.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <returns>Base64 encoded cache key prefixed by <see cref="CacheSettings.KeyPrefix"/>.</returns>
        public string GetPrefixedKey(string key)
        {
            return KeyPrefix + key.Base64Encode();
        }
    }
}