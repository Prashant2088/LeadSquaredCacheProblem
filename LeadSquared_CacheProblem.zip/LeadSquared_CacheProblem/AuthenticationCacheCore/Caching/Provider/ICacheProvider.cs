﻿// <copyright file="ICacheProvider.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>


using AuthenticationCacheCore.Caching;
using System.Text.Json;

namespace AuthenticationCacheCore.Provider
{
    /// <summary>
    /// Represents Interface for cache provider.
    /// </summary>
    public interface ICacheProvider
    {
        #region Get & Set Methods
        /// <summary>
        /// Gets or sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="delegateFunc">
        /// The function which checks whether item exists in cache and retrieves and adds the value to cache if that doesn't exist.
        /// </param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <returns>Cached object.</returns>
        T GetOrSetValue<T>(string key,
            Func<T> delegateFunc,
            CacheEntryOptions? options = null,
            JsonSerializerOptions? serializerSettings = null) where T : class;

        /// <summary>
        /// Gets or sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="delegateFunc">
        /// The function which checks whether item exists in cache and retrieves and adds the value to cache if that doesn't exist.
        /// </param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <returns>Cached object.</returns>
        Task<T> GetOrSetValueAsync<T>(string key,
            Func<Task<T>> delegateFunc,
            CacheEntryOptions? options = null,
            JsonSerializerOptions? serializerSettings = null) where T : class;

        /// <summary>
        /// Gets or sets cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <param name="delegateFunc">
        /// The function which checks whether item exists in cache and retrieves string value and adds it to cache if that doesn't exist.
        /// </param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Cached value.</returns>
        Task<string> GetOrSetValueAsync(string key, Func<Task<string>> delegateFunc, CacheEntryOptions? options = null);
        #endregion

        #region Get Methods
        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached object if it exits otherwise null.</returns>
        T GetValue<T>(string key) where T : class;

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached object if it exits otherwise null.</returns>
        Task<T> GetValueAsync<T>(string key) where T : class;

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached value as string if it exits otherwise null.</returns>
        Task<string> GetValueAsync(string key);
        #endregion

        #region Delete Methods
        /// <summary>
        /// Removes the cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <returns>Task</returns>
        Task RemoveAsync(string key);

        #endregion

        #region Set Methods
        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        void SetValue<T>(string key,
            T value,
            JsonSerializerOptions? serializerSettings = null,
            CacheEntryOptions? options = null) where T : class;

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        Task SetValueAsync<T>(string key,
            T value,
            JsonSerializerOptions? serializerSettings = null,
            CacheEntryOptions? options = null) where T : class;

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        Task SetValueAsync(string key, string value, CacheEntryOptions? options = null);

        #endregion
    }
}