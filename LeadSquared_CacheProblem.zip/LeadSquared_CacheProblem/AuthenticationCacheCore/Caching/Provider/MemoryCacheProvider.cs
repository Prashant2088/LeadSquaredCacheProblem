﻿// <copyright file="MemoryCacheProvider.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using System.Text.Json;

using AuthenticationCacheCore.Caching;
using AuthenticationCacheCore.Extensions;
using Microsoft.Extensions.Caching.Memory;

namespace AuthenticationCacheCore.Provider
{
    /// <summary>
    /// Represents in memory cache provider.
    /// </summary>
    public class MemoryCacheProvider : CacheProvider
    {
        #region Declaration
        private readonly MemoryCacheEntryOptions _cacheEntryOptions;

        private readonly CacheSettings _cacheSettings;

        private readonly IMemoryCache _memoryCache;

        #endregion

        #region Constructor
        /// <summary>
        /// Initializes new instance of <see cref="MemoryCacheProvider"/>.
        /// </summary>
        /// <param name="cache"><see cref="IMemoryCache">The in memory cache</see>.</param>
        /// <param name="defaultCacheEntryOptions"><see cref="MemoryCacheEntryOptions">The default cache entry options</see>.</param>
        /// <param name="cacheSettings"><see cref="CacheSettings">The cache settingws</see>.</param>
        public MemoryCacheProvider(IMemoryCache cache, MemoryCacheEntryOptions defaultCacheEntryOptions, CacheSettings cacheSettings)
        {
            _memoryCache = cache ?? throw new ArgumentNullException(nameof(cache));
            _cacheEntryOptions = defaultCacheEntryOptions;
            _cacheSettings = cacheSettings ?? throw new ArgumentNullException(nameof(cacheSettings));
        }

        #endregion

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached object if it exits otherwise null.</returns>
        public override T GetValue<T>(string key) where T : class
        {
            VerifyCacheKey(key);

            return GetKeyValue<T>(key);
        }

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached object if it exits otherwise null.</returns>
        public override Task<T> GetValueAsync<T>(string key) where T : class
        {
            VerifyCacheKey(key);

            return Task.Run(() => GetKeyValue<T>(key));
        }

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached value as string if it exits otherwise null.</returns>
        public override Task<string> GetValueAsync(string key)
        {
            VerifyCacheKey(key);

            return Task.Run(() => GetValue(key));
        }

        /// <summary>
        /// Removes the cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <returns>Task</returns>
        public override Task RemoveAsync(string key)
        {
            VerifyCacheKey(key);

            return Task.Run(() => Remove(key));
        }



        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        public override void SetValue<T>(string key,
            T value,
            JsonSerializerOptions? serializerSettings = null,
            CacheEntryOptions? options = null) where T : class
        {
            var memoryCacheEntryOptions = InitSetValue(key, options!);

            _memoryCache.Set(_cacheSettings.GetPrefixedKey(key), value, memoryCacheEntryOptions);
        }

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        public override async Task SetValueAsync<T>(string key,
            T value,
            JsonSerializerOptions? serializerSettings = null,
            CacheEntryOptions? options = null) where T : class
        {
            var memoryCacheEntryOptions = await InitSetValueAsync(key, options!).ConfigureAwait(false);

            _memoryCache.Set(_cacheSettings.GetPrefixedKey(key), value, memoryCacheEntryOptions);
        }

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        public override async Task SetValueAsync(string key, string value, CacheEntryOptions? options = null)
        {
            var memoryCacheEntryOptions = await InitSetValueAsync(key, options!).ConfigureAwait(false);

            _memoryCache.Set(_cacheSettings.GetPrefixedKey(key), value, memoryCacheEntryOptions);
        }

        private T GetKeyValue<T>(string key) where T : class
        {
            if (_memoryCache.TryGetValue(_cacheSettings.GetPrefixedKey(key), out object value))
            {
                return (T)value;
            }

            return default!;
        }

        private string GetValue(string key)
        {
            if (_memoryCache.TryGetValue(_cacheSettings.GetPrefixedKey(key), out string value))
            {
                return value;
            }
            return string.Empty;
        }

        private MemoryCacheEntryOptions InitSetValue(string key, CacheEntryOptions options)
        {
            VerifyCacheKey(key);

            RemoveAsync(key);

            if (options != null)
            {
                return options.MemoryCacheEntryOptions();
            }

            return _cacheEntryOptions;
        }
        private async Task<MemoryCacheEntryOptions> InitSetValueAsync(string key, CacheEntryOptions options)
        {
            VerifyCacheKey(key);

            await RemoveAsync(key).ConfigureAwait(false);

            if (options != null)
            {
                return options.MemoryCacheEntryOptions();
            }

            return _cacheEntryOptions;
        }

        private void Remove(string key)
        {
            _memoryCache.Remove(_cacheSettings.GetPrefixedKey(key));
        }
    }
}