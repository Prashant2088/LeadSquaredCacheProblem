﻿// < copyright file = "CacheProvider.cs" company = "LeadSquared" >
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using AuthenticationCacheCore.Caching;
using System.Text.Json;

namespace AuthenticationCacheCore.Provider
{
    /// <summary>
    /// Represents base implementation of cache providers.
    /// </summary>
    public abstract class CacheProvider : ICacheProvider
    {
        #region Get & Set Methods

        /// <summary>
        /// Gets or sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="delegateFunc">
        /// The function which checks whether item exists in cache and retrieves and adds the value to cache if that doesn't exist.
        /// </param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <returns>Cached object.</returns>
        public virtual async Task<T> GetOrSetValueAsync<T>(
            string key,
            Func<Task<T>> delegateFunc,
            CacheEntryOptions? options = null,
            JsonSerializerOptions? serializerSettings = null)
                    where T : class
        {
            if (delegateFunc is null)
            {
                throw new ArgumentNullException(nameof(delegateFunc));
            }

            var result = await GetValueAsync<T>(key).ConfigureAwait(false);
            if (result != null)
            {
                return result;
            }

            result = await delegateFunc().ConfigureAwait(false);

            await SetValueAsync(key, result, serializerSettings!, options!).ConfigureAwait(false);

            return result;
        }

        /// <summary>
        /// Gets or sets cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <param name="delegateFunc">
        /// The function which checks whether item exists in cache and retrieves string value and adds it to cache if that doesn't exist.
        /// </param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Cached value.</returns>
        public async Task<string> GetOrSetValueAsync(string key, Func<Task<string>> delegateFunc, CacheEntryOptions? options = null)
        {
            if (delegateFunc is null)
            {
                throw new ArgumentNullException(nameof(delegateFunc));
            }

            var result = await GetValueAsync(key).ConfigureAwait(false);
            if (result != null)
            {
                return result;
            }

            result = await delegateFunc().ConfigureAwait(false);

            await SetValueAsync(key, result, options!).ConfigureAwait(false);

            return result;
        }


        /// <summary>
        /// Gets or sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="delegateFunc">
        /// The function which checks whether item exists in cache and retrieves and adds the value to cache if that doesn't exist.
        /// </param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <returns>Cached object.</returns>
        public virtual T GetOrSetValue<T>(
            string key,
            Func<T> delegateFunc,
            CacheEntryOptions? options = null,
            JsonSerializerOptions? serializerSettings = null)
                    where T : class
        {
            if (delegateFunc is null)
            {
                throw new ArgumentNullException(nameof(delegateFunc));
            }

            var result = GetValue<T>(key);
            if (result != null)
            {
                return result;
            }

            result = delegateFunc();

            SetValue(key, result, serializerSettings!, options!);

            return result;
        }
        #endregion

        #region Get  Methods

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached object if it exits otherwise null.</returns>
        public abstract T GetValue<T>(string key) where T : class;

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached object if it exits otherwise null.</returns>
        public abstract Task<T> GetValueAsync<T>(string key) where T : class;

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached value as string if it exits otherwise null.</returns>
        public abstract Task<string> GetValueAsync(string key);

        #endregion

        #region Remove  Methods
        /// <summary>
        /// Removes the cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <returns>Task</returns>
        public abstract Task RemoveAsync(string key);

        #endregion

        #region Set  Methods

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        public abstract void SetValue<T>(
            string key,
            T value,
            JsonSerializerOptions? serializerSettings = null,
            CacheEntryOptions? options = null) where T : class;

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        public abstract Task SetValueAsync<T>(
            string key,
            T value,
            JsonSerializerOptions? serializerSettings = null,
            CacheEntryOptions? options = null) where T : class;

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        public abstract Task SetValueAsync(string key, string value, CacheEntryOptions? options = null);

        #endregion

        #region Common
        /// <summary>
        /// Verifies the cache key.
        /// </summary>
        /// <param name="key"></param>
        /// <exception cref="CachingException">Throws exception when the cache key is not valid.</exception>
        protected static void VerifyCacheKey(string key)
        {
            if (string.IsNullOrEmpty(key) && string.IsNullOrWhiteSpace(key))
            {
                throw new ArgumentNullException("Invalid Cache Key.");
            }
        }
        #endregion
    }
}