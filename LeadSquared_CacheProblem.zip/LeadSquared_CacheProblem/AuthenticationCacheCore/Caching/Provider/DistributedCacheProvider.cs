﻿// <copyright file="DistributedCacheProvider.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using System.Text.Json;

using AuthenticationCacheCore.Caching;
using AuthenticationCacheCore.Extensions;
using Microsoft.Extensions.Caching.Distributed;

namespace AuthenticationCacheCore.Provider
{
    /// <summary>
    /// Represents in distributed cache provider.
    /// </summary>
#pragma warning disable CS8603
    public class DistributedCacheProvider : CacheProvider
    {
        private readonly DistributedCacheEntryOptions _cacheEntryOptions;

        private readonly CacheSettings _cacheSettings;

        private readonly IDistributedCache _distributedCache;

        /// <summary>
        /// Initializes new instance of <see cref="DistributedCacheProvider"/>.
        /// </summary>
        /// <param name="cache"><see cref="IDistributedCache">The in memory cache</see>.</param>
        /// <param name="cacheEntryOptions"><see cref="DistributedCacheEntryOptions">The default cache entry options</see>.</param>
        /// <param name="cacheSettings"><see cref="CacheSettings">The cache settingws</see>.</param>
        public DistributedCacheProvider(IDistributedCache cache, DistributedCacheEntryOptions cacheEntryOptions, CacheSettings cacheSettings)
        {
            _distributedCache = cache ?? throw new ArgumentNullException(nameof(cache));
            _cacheEntryOptions = cacheEntryOptions;
            _cacheSettings = cacheSettings ?? throw new ArgumentNullException(nameof(cacheSettings));
        }

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached object if it exits otherwise null.</returns>
        public override T GetValue<T>(string key)
           where T : class
        {
            VerifyCacheKey(key);

            var data = _distributedCache.GetString(_cacheSettings.GetPrefixedKey(key));
            ;
            if (data is not null)
            {
                return data.Base64Decode().JsonDeSerialize<T>();
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached object if it exits otherwise null.</returns>
        public override async Task<T> GetValueAsync<T>(string key)
           where T : class
        {
            VerifyCacheKey(key);

            var data = await _distributedCache.GetStringAsync(_cacheSettings.GetPrefixedKey(key)).ConfigureAwait(false);
            if (data is not null)
            {
                return data.Base64Decode().JsonDeSerialize<T>();
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Gets cache entry value.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <returns>Cached value as string if it exits otherwise null.</returns>
        public override Task<string> GetValueAsync(string key)
        {
            VerifyCacheKey(key);

            return _distributedCache.GetStringAsync(_cacheSettings.GetPrefixedKey(key));
        }

        /// <summary>
        /// Removes the cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <returns>Task</returns>
        public override Task RemoveAsync(string key)
        {
            VerifyCacheKey(key);

            return _distributedCache.RemoveAsync(_cacheSettings.GetPrefixedKey(key));
        }

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        public override void SetValue<T>(
            string key,
            T value,
            JsonSerializerOptions? serializerSettings,
            CacheEntryOptions? options = null)
             where T : class
        {
            var distributedCacheEntryOptions = InitSetValue(key, options!);

            _distributedCache.SetString(_cacheSettings.GetPrefixedKey(key),
              value.JsonSerialize(serializerSettings).Base64Encode(),
              distributedCacheEntryOptions!);
        }

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <typeparam name="T">The type of the value that is cached.</typeparam>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="serializerSettings">(Optional) <see cref="JsonSerializerOptions">Json serializer settings</see>.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        public override async Task SetValueAsync<T>(
            string key,
            T value,
            JsonSerializerOptions? serializerSettings,
            CacheEntryOptions? options = null)
             where T : class
        {
            var distributedCacheEntryOptions = await InitSetValueAsync(key, options!).ConfigureAwait(false);

            await _distributedCache.SetStringAsync(_cacheSettings.GetPrefixedKey(key),
               value.JsonSerialize(serializerSettings).Base64Encode(),
               distributedCacheEntryOptions!).ConfigureAwait(false);
        }

        /// <summary>
        /// Sets cache entry.
        /// </summary>
        /// <param name="key">The cache key.</param>
        /// <param name="value">The cache value.</param>
        /// <param name="options">(Optional) <see cref="CacheEntryOptions">Cache options</see>.</param>
        /// <returns>Task</returns>
        public override async Task SetValueAsync(string key, string value, CacheEntryOptions? options = null)
        {
            var distributedCacheEntryOptions = await InitSetValueAsync(key, options!).ConfigureAwait(false);
            await _distributedCache.SetStringAsync(_cacheSettings.GetPrefixedKey(key),
                                                   value.Base64Encode(),
                                                   distributedCacheEntryOptions)
                                   .ConfigureAwait(false);
        }

        private Task<DistributedCacheEntryOptions> InitSetValueAsync(string key, CacheEntryOptions options)
        {
            VerifyCacheKey(key);

            RemoveAsync(key);

            if (options != null)
            {
                return Task.FromResult(options.DistributedCacheEntryOptions());
            }

            return Task.FromResult(_cacheEntryOptions);
        }

        private DistributedCacheEntryOptions InitSetValue(string key, CacheEntryOptions options)
        {
            VerifyCacheKey(key);
            RemoveAsync(key);

            if (options != null)
            {
                return options.DistributedCacheEntryOptions();
            }

            return _cacheEntryOptions;
        }
    }
}