// <copyright file="Program.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using AuthenticationCache.Api;

#pragma warning disable CA1812
var ServiceName = "AuthenticationCache Service";
var builder = WebApplication.CreateBuilder(args);
var startup = new Startup(builder, ServiceName);
startup.ConfigureServices(builder.Services, builder.Configuration);
var app = builder.Build();
startup.Configure(app, builder);
startup.ConfigureRun(app);


