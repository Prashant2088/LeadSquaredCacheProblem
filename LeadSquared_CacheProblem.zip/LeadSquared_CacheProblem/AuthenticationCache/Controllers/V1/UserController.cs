﻿// < copyright file = "UserController.cs" company = "LeadSquared" >
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>


using AuthenticationCache.Application.DTO.Request;
using AuthenticationCache.Application.DTO.Response;
using AuthenticationCache.Application.Util;
using AuthenticationCacheCore.Provider;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;

namespace AuthenticationCache.Controllers.V1
{
    /// <summary>
    /// User COntroller
    /// </summary>
    [ApiController]
    [Route("v{version:apiVersion}/UserService")]
    [ApiVersion("1")]
    public class UserController : ControllerBase
    {
        #region Declaration
        private readonly ICacheProvider _cacheProvider;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IConfiguration _configuration;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="UserController"/> class.
        /// </summary>
        /// <param name="cacheProvider">Cache Provider</param>
        /// <param name="userManager"></param>
        /// <param name="roleManager"></param>
        /// <param name="configuration"></param>
        public UserController(
            ICacheProvider cacheProvider,
            UserManager<IdentityUser> userManager,
            RoleManager<IdentityRole> roleManager,
            IConfiguration configuration)
        {
            _cacheProvider = cacheProvider ?? throw new ArgumentNullException(nameof(cacheProvider));
            _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
            _roleManager = roleManager ?? throw new ArgumentNullException(nameof(roleManager));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        #endregion

        #region Declaration

        /// <summary>
        /// This Require Authorization. Get the Token from UserToken API and use to get the results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("getuserprofile")]
        [ProducesResponseType(typeof(UserProfile), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        [Authorize]
        public async Task<IActionResult> GetUserProfileAsync([FromQuery] TokenRequestModel request)
        {
            UserProfile? userProfile = new();
            if (request is null)
            {
                return BadRequest();
            }

            //Cache Set Object
            userProfile.Users = await _cacheProvider.GetOrSetValueAsync
                       (
                           $"{nameof(IdentityUser)}:{request.Username}",
                           async () => { return await _userManager.FindByNameAsync(request.Username).ConfigureAwait(false); }
                       ).ConfigureAwait(false);

            //Response Validation Check
            if (userProfile.Users != null)
            {
                if (await _userManager.CheckPasswordAsync(userProfile.Users, request.Password))
                {
                    userProfile.UserRoles = await _cacheProvider.GetOrSetValueAsync
                          (
                              $"Roles:{userProfile.Users}",
                              async () => { return await _userManager.GetRolesAsync(userProfile.Users).ConfigureAwait(false); }
                          ).ConfigureAwait(false);

                    userProfile.Claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name,  userProfile.Users.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                };

                    foreach (var userRole in userProfile.UserRoles)
                    {
                        userProfile.Claims.Add(new Claim(ClaimTypes.Role, userRole));
                    }
                }
                else
                {
                    return NotFound("Invalid Password. Please try with Valid Password.");
                }
            }

            if (userProfile.Claims == null || userProfile.UserRoles == null || userProfile.Users == null)
            {
                return NotFound("User Profile Not found for the requested UserName");
            }
            return Ok(userProfile);
        }

        /// <summary>
        /// This Require Authorization. Get the Token from UserToken API and use to get the results.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet("removeUserProfilefromCache")]
        [ProducesResponseType(typeof(UserProfile), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        [Authorize]
        public async Task<IActionResult> RemoveUserProfileFromCacheAsync([FromQuery] TokenRequestModel request)
        {
            if (request is null)
            {
                return BadRequest();
            }

            //Remove the Identity User Cache Object
            await _cacheProvider.RemoveAsync($"{nameof(IdentityUser)}:{request.Username}");

            await _cacheProvider.RemoveAsync($"Roles:{request.Username}");

            return Ok();
        }

        [HttpPost("getusertoken")]
        [ProducesResponseType(typeof(UserTokenResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> GetUserJWTTokenAsync(
            [FromBody] TokenRequestModel request)
        {

            if (request is null)
            {
                return BadRequest();
            }

            //Cache Set Object
            var userqueryResult = await _cacheProvider.GetOrSetValueAsync
                       (
                           $"{nameof(IdentityUser)}:{request.Username}",
                           async () => { return await _userManager.FindByNameAsync(request.Username).ConfigureAwait(false); }
                       ).ConfigureAwait(false);

            if (userqueryResult != null &&
                await _userManager.CheckPasswordAsync(userqueryResult, request.Password))
            {
                var userRoles = await _cacheProvider.GetOrSetValueAsync
                      (
                          $"Roles:{userqueryResult}",
                          async () => { return await _userManager.GetRolesAsync(userqueryResult).ConfigureAwait(false); }
                      ).ConfigureAwait(false);

                var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, userqueryResult.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                };

                foreach (var userRole in userRoles)
                {
                    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                }

                var token = CreateToken(authClaims);

                return Ok(new UserTokenResponse()
                {
                    UserJWTtoken = new JwtSecurityTokenHandler().WriteToken(token),
                    Expiration = token.ValidTo
                });
            }
            return Unauthorized();
        }

        [HttpPost("registeruser")]
        [ProducesResponseType(typeof(UserResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> RegisterUserAsync
            ([FromBody] UserRequestModel request)
        {
            if (request is null)
            {
                return BadRequest();
            }

            var userExists = await _userManager.FindByNameAsync(request.Username);
            if (userExists != null)
                return StatusCode((int)HttpStatusCode.InternalServerError, new UserResponse { Status = "Error", Message = "User is already exists in or Database records!" });

            IdentityUser user = new()
            {
                Email = request.Email,
                SecurityStamp = Guid.NewGuid().ToString(),
                UserName = request.Username
            };
            var result = await _userManager.CreateAsync(user, request.Password);
            if (!result.Succeeded)
                return StatusCode((int)HttpStatusCode.InternalServerError, new UserResponse { Status = "Error", Message = "User creation failed! Please try again with valid user details." });

            return Ok(new UserResponse { Status = "Success", Message = "User is created successfully!" });
        }

        [HttpPost("registeradminuser")]
        [ProducesResponseType(typeof(UserResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.Unauthorized)]
        public async Task<IActionResult> RegisterAdminUserAsync
            ([FromBody] UserRequestModel request)
        {
            var userExists = await _userManager.FindByNameAsync(request.Username);
            if (userExists != null)
                return StatusCode((int)HttpStatusCode.InternalServerError, new UserResponse { Status = "Error", Message = "User is already exists in our database!" });

            IdentityUser user = new()
            {
                Email = request.Email,
                SecurityStamp = Guid.NewGuid().ToString(),
                UserName = request.Username
            };
            var result = await _userManager.CreateAsync(user, request.Password);
            if (!result.Succeeded)
                return StatusCode((int)HttpStatusCode.InternalServerError, new UserResponse { Status = "Error", Message = "User creation failed! Please try again with valid user details." });

            if (!await _roleManager.RoleExistsAsync(UserRoles.Admin))
                await _roleManager.CreateAsync(new IdentityRole(UserRoles.Admin));
            if (!await _roleManager.RoleExistsAsync(UserRoles.User))
                await _roleManager.CreateAsync(new IdentityRole(UserRoles.User));

            if (await _roleManager.RoleExistsAsync(UserRoles.Admin))
            {
                await _userManager.AddToRoleAsync(user, UserRoles.Admin);
            }
            if (await _roleManager.RoleExistsAsync(UserRoles.Admin))
            {
                await _userManager.AddToRoleAsync(user, UserRoles.User);
            }
            return Ok(new UserResponse { Status = "Success", Message = "User is created successfully!" });
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// Creation of JWT Token
        /// </summary>
        /// <param name="authClaims"></param>
        /// <returns></returns>
        private JwtSecurityToken CreateToken(List<Claim> authClaims)
        {
            var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));

            var token = new JwtSecurityToken(
                issuer: _configuration["JWT:ValidIssuer"],
                audience: _configuration["JWT:ValidAudience"],
                expires: DateTime.Now.AddHours(3),
                claims: authClaims,
                signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                );

            return token;
        }

        #endregion
    }
}
