﻿// < copyright file = "UserProfile.cs" company = "LeadSquared" >
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using Microsoft.AspNetCore.Identity;
using System.Security.Claims;

namespace AuthenticationCache.Application.DTO.Response
{
    /// <summary>
    /// User Profile Model
    /// </summary>
    public class UserProfile
    {
        /// <summary>
        /// Get or set Identity User
        /// </summary>
        public IdentityUser? Users { get; set; }

        /// <summary>
        /// Get or set User Roles
        /// </summary>
        public IList<string>? UserRoles { get; set; }

        /// <summary>
        /// Get or set Auth CLaims of User
        /// </summary>
        public IList<Claim>? Claims { get; set; }
    }
}
