﻿// < copyright file = "UserTokenResponse.cs" company = "LeadSquared" >
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

namespace AuthenticationCache.Application.DTO.Response
{
    /// <summary>
    /// User Token Response Model
    /// </summary>
    public class UserTokenResponse
    {
        /// <summary>
        /// Get or Set JWT Token
        /// </summary>
        public string? UserJWTtoken { get; set; }

        /// <summary>
        /// Get or Set Expiration Time
        /// </summary>
        public DateTime? Expiration { get; set; }
    }
}
