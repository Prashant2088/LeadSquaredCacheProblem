﻿// < copyright file = "UserResponse.cs" company = "LeadSquared" >
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

namespace AuthenticationCache.Application.DTO.Response
{
    /// <summary>
    /// User Response Model
    /// </summary>
    public class UserResponse
    {
        /// <summary>
        /// Get or Set Status
        /// </summary>
        public string? Status { get; set; }

        /// <summary>
        /// Get or Set Message
        /// </summary>
        public string? Message { get; set; }
    }
}
