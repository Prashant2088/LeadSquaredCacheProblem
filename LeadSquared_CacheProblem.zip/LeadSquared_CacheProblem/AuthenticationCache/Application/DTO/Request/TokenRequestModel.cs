﻿// <copyright file="TokenRequestModel.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using System.ComponentModel.DataAnnotations;

namespace AuthenticationCache.Application.DTO.Request
{
    /// <summary>
    /// Token Request Model
    /// </summary>
    public class TokenRequestModel
    {

        /// <summary>
        /// Get or Set UserName
        /// </summary>
        [Required(ErrorMessage = "User Name is required")]
        public string? Username { get; set; }

        /// <summary>
        /// Get or Set Password
        /// </summary>
        [Required(ErrorMessage = "Password is required")]
        public string? Password { get; set; }
    }
}
