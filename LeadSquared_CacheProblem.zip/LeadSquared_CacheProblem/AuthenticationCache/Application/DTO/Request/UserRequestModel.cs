﻿// <copyright file="UserRequestModel.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using System.ComponentModel.DataAnnotations;

namespace AuthenticationCache.Application.DTO.Request
{
    /// <summary>
    /// User Request Model Class
    /// </summary>
    public class UserRequestModel
    {
        /// <summary>
        /// Get or Set UserName
        /// </summary>
        [Required(ErrorMessage = "User Name is required")]
        public string? Username { get; set; }

        /// <summary>
        /// Get or Set Email Address
        /// </summary>
        [EmailAddress]
        [Required(ErrorMessage = "Email is required")]
        public string? Email { get; set; }

        /// <summary>
        /// Get or Set Password
        /// </summary>
        [Required(ErrorMessage = "Password is required")]
        public string? Password { get; set; }
    }
}
