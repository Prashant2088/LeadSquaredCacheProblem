﻿// < copyright file = "UserRoles.cs" company = "LeadSquared" >
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

namespace AuthenticationCache.Application.Util
{
    /// <summary>
    /// User Roles Constants
    /// </summary>
    public static class UserRoles
    {
        /// <summary>
        /// Admin Constatnt string
        /// </summary>
        public const string Admin = "Admin";

        /// <summary>
        /// User Constant String
        /// </summary>
        public const string User = "User";
    }
}
