﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AuthenticationCache.Infrastructure
{
    public class AuthenticationCacheDbContext : IdentityDbContext<IdentityUser>
    {
        public AuthenticationCacheDbContext(DbContextOptions<AuthenticationCacheDbContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
    }
}
