﻿// <copyright file="Startup.cs" company="LeadSquared">
//     Copyright (c) LeadSquared. All rights reserved.
// </copyright>

using AuthenticationCache.Infrastructure;
using AuthenticationCacheCore.Caching;
using AuthenticationCacheCore.Extensions;
using AuthenticationCacheCore.Provider;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Tokens;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.Json.Serialization;

namespace AuthenticationCache.Api
{
    /// <summary>
    /// API Configurator for ServiceName . 
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Constant String for Data DB Context
        /// </summary>
        public const string DbContextName = "ApplicationDBContext";

        /// <summary>
        /// Gets current service name.
        /// </summary>
        public string? ServiceName { get; }

        /// <summary>
        /// Service Provider
        /// </summary>
        private IServiceProvider? _serviceProvider;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="WebApplicationBuilder"></param>
        /// <param name="name"></param>
        public Startup(WebApplicationBuilder WebApplicationBuilder, string name)
        {
            if (WebApplicationBuilder is not null)
            {
                ServiceName = !string.IsNullOrEmpty(name) ? name : AppDomain.CurrentDomain.FriendlyName;
                Console.Title = ServiceName;
            }
        }

        /// <summary>
        /// Configure Services
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public void ConfigureServices(IServiceCollection services, IConfigurationRoot configuration)
        {
            if (configuration is null)
            {
                throw new ArgumentNullException(nameof(configuration));
            }

            if (services is null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            var _healthChecksBuilder = services.AddHealthChecks();

            //Adding DB Context
            services.AddDbContext<AuthenticationCacheDbContext>(options =>
          {
              options.UseSqlServer(configuration.GetConnectionString(DbContextName));
          });

            services.AddHttpContextAccessor();

            services.AddVersioning();

            _serviceProvider = services.BuildServiceProvider();

            // Add API Documentation
            services.AddApiDocumentation(configuration, _serviceProvider, ServiceName!);

            services.AddCors(options =>
            {
                options.AddPolicy("AllowAnyOrigin", builder => builder
                    .AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader());
            });

            // Add services to the container.
            var mvcBuilder = services.AddControllers();

            mvcBuilder.AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
                options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
                options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
            });

            // Adding JWT Idetity
            services.AddIdentity<IdentityUser, IdentityRole>()
            .AddEntityFrameworkStores<AuthenticationCacheDbContext>()
            .AddDefaultTokenProviders();

            // Adding Authentication
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                options.SaveToken = true;
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = new TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = false,
                    ValidateIssuerSigningKey = true,
                    ValidAudience = configuration["JWT:ValidAudience"],
                    ValidIssuer = configuration["JWT:ValidIssuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["JWT:Secret"]))
                };
            });

            //Redis Cache Injection Using Stack Exchange
            var cacheSettings = GetCacheSettings(configuration);
            var ClientName = cacheSettings.RedisCacheOptions!.ConfigurationOptions.ClientName;
            services.AddSingleton(cacheSettings);
            services.AddSingleton(cacheSettings.RedisCacheOptions!);
            services.AddSingleton(cacheSettings.CacheEntryOptions!.DistributedCacheEntryOptions());

            services.AddStackExchangeRedisCache(options =>
            {
                var redisCacheOptions = cacheSettings.RedisCacheOptions;
                options.Configuration = redisCacheOptions!.Configuration;
                options.ConfigurationOptions = redisCacheOptions.ConfigurationOptions;

                //If No Instance Name Defined ,Use Executable Assembly Name
                options.InstanceName = redisCacheOptions.InstanceName ?? Assembly.GetExecutingAssembly().GetName().Name;
            });

            //Cache Provider (Distributed /Memory)
            services.AddTransient<ICacheProvider>(provider =>
            {
                var settings = provider.GetService<CacheSettings>();
                if (settings!.CacheType == CacheType.Distributed)
                {
                    var distributedCache = provider.GetRequiredService<IDistributedCache>();
                    return new DistributedCacheProvider(distributedCache, settings.CacheEntryOptions!.DistributedCacheEntryOptions(), settings);
                }

                var memoryCache = provider.GetRequiredService<IMemoryCache>();
                return new MemoryCacheProvider(memoryCache, settings.CacheEntryOptions!.MemoryCacheEntryOptions(), settings);
            });

            //Redis Heath Checks
            _healthChecksBuilder.AddRedis(
               redisConnectionString: cacheSettings.GetConnectionString(),
               name: $"Health Check - Redis - {ClientName}",
               tags: new string[] { ClientName });

            services.AddMemoryCache();

        }

        /// <summary>
        /// Configure.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="builder"></param>
        public void Configure(WebApplication app, WebApplicationBuilder builder)
        {
            //Use Routing
            app.UseRouting();

            //Use Cors
            app.UseCors("AllowAnyOrigin");

            //Use Authenication
            app.UseAuthentication();

            //Use Authorization
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.MapControllers();

            app.UseHttpsRedirection();

            if (app is not null)
            {
                // Configure the HTTP request pipeline.
                if (app.Environment.IsDevelopment())
                {
                    app.UseDeveloperExceptionPage();
                }
            }

            if (builder is not null)
            {
                if (builder.Configuration["ApiDocumentSettings:Enabled"].Equals("True", StringComparison.OrdinalIgnoreCase))
                {
                    app.UseOpenApi();
                    app.UseSwaggerUi3();
                }
            }
        }

        /// <summary>
        /// Application Run Method
        /// </summary>
        /// <param name="app"></param>
        public void ConfigureRun(WebApplication app)
        {
            if (app is not null)
            {
                app!.Run();
            }
        }

        /// <summary>
        /// Get Cache Settings
        /// </summary>
        /// <param name="configuration"></param>
        /// <returns></returns>
        private CacheSettings GetCacheSettings(IConfiguration configuration)
        {
            var cacheSettings = configuration.GetSection(nameof(CacheSettings)).Get<CacheSettings>();
            var endPointsSection = configuration.GetSection("CacheSettings:RedisCacheOptions:ConfigurationOptions:EndPoints").GetChildren();
            var endPoints = cacheSettings.RedisCacheOptions!.ConfigurationOptions.EndPoints;
            foreach (var endPointSection in endPointsSection)
            {
                var host = endPointSection.GetValue<string>("Host");
                var port = endPointSection.GetValue<int>("Port");
                var endPoint = new DnsEndPoint(host, port);
                endPoints.Add(endPoint);
            }

            return cacheSettings;
        }
    }
}
